/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modeltest;

/**
 *
 * @author Gabriel Samartin
 */
import model.Criatura;
import model.HabilidadeDeAtaque;
import model.TipoElemental;
import service.CalculadoraElemental;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import static org.mockito.Mockito.*;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.Assertions;
import java.util.Collections;


class HabilidadeDeAtaqueTest {

    // 1. Mock: Simulamos a CalculadoraElemental
    @Mock
    private CalculadoraElemental mockCalculadora;

    @Test
    void deveAplicarDanoCorretamente_QuandoCalculadoraRetornaNeutro() {
        
        Criatura atacante = new Criatura("Fera Atacante", 100, 20, 0, TipoElemental.FOGO, 10, Collections.emptyList());
        Criatura alvo = new Criatura("Tartaruga", 100, 10, 5, TipoElemental.AGUA, 5, Collections.emptyList());
        
        
        HabilidadeDeAtaque ataque = new HabilidadeDeAtaque("Triturador", 50, mockCalculadora);

        
        double danoEsperado = 100.0;
        when(mockCalculadora.calcularDanoFinal(any(Criatura.class), any(Criatura.class), anyDouble()))
            .thenReturn(danoEsperado);

        
        ataque.usar(atacante, alvo);

       
        Assertions.assertEquals(0, alvo.getHp(), 
            "O HP do alvo deve ser 0 (100 - 100), provando que o Mock funcionou e o dano foi aplicado.");

        
        verify(mockCalculadora).calcularDanoFinal(any(), any(), anyDouble());
    }

    @Test
    void deveLimitarDanoEmZero_TesteDeValorLimite() {
      
        
      
        Criatura atacante = new Criatura("Fera", 100, 20, 0, TipoElemental.FOGO, 10, Collections.emptyList());
        Criatura alvo = new Criatura("Teste Limite", 10, 10, 5, TipoElemental.AGUA, 5, Collections.emptyList());
        
      
        HabilidadeDeAtaque ataque = new HabilidadeDeAtaque("Super Golpe", 50, mockCalculadora);
        when(mockCalculadora.calcularDanoFinal(any(), any(), anyDouble())).thenReturn(200.0);
        
    
        ataque.usar(atacante, alvo);
        
       
        Assertions.assertEquals(0, alvo.getHp(), 
            "O HP da criatura deve ser limitado em 0, mesmo que o dano final seja 200.");
    }
}