/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Gabriel Samartin
 */
package servicetest;

import model.TipoElemental;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import service.CalculadoraElemental;

class CalculadoraElementalTest {

    private CalculadoraElemental calculadora = new CalculadoraElemental();

    @Test
    void deveCalcularDanoSuperEficaz_FogoContraTerra() {
       
        double multiplicador = calculadora.calcularVantagem(TipoElemental.FOGO, TipoElemental.TERRA);
        Assertions.assertEquals(1.5, multiplicador, "Fogo contra Terra deve ser 1.5");
    }
    
    @Test
    void deveCalcularDanoPoucoEficaz_FogoContraAgua() {
        
        double multiplicador = calculadora.calcularVantagem(TipoElemental.FOGO, TipoElemental.AGUA);
            Assertions.assertEquals(0.5, multiplicador, "Fogo contra Água deve ser 0.5");
    }

    @Test
    void deveCalcularDanoNeutro_TerraContraLuz() {
     
        double multiplicador = calculadora.calcularVantagem(TipoElemental.TERRA, TipoElemental.LUZ);
        Assertions.assertEquals(1.0, multiplicador, "Terra contra Luz deve ser 1.0");
    }
}
