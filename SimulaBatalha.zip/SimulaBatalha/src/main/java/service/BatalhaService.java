package service;

import model.*;
import java.util.List;
import java.util.Arrays;

public class BatalhaService {

    private Criatura criatura1;
    private Criatura criatura2;
    private CalculadoraElemental calculadora;

    public BatalhaService(Criatura criatura1, Criatura criatura2) {
        this.criatura1 = criatura1;
        this.criatura2 = criatura2;
        this.calculadora = new CalculadoraElemental();
    }
    
    public void iniciarBatalha() {
        System.out.println("--- INÍCIO DA BATALHA ---");
        System.out.println(criatura1.getNome() + " vs " + criatura2.getNome());
        
        Criatura primeiroTurno = determinarIniciativa();
        Criatura segundoTurno = (primeiroTurno == criatura1) ? criatura2 : criatura1;

        while (criatura1.estaViva() && criatura2.estaViva()) {
            
            executarTurno(primeiroTurno, segundoTurno);
            if (!segundoTurno.estaViva()) break;

            
            executarTurno(segundoTurno, primeiroTurno);
        }

        declararVencedor();
        System.out.println("--- FIM DA BATALHA ---");
    }

    private Criatura determinarIniciativa() {
       
        if (criatura1.getVelocidade() > criatura2.getVelocidade()) {
            return criatura1;
        } else if (criatura2.getVelocidade() > criatura1.getVelocidade()) {
            return criatura2;
        } else {
           
            return criatura1;
        }
    }

    private void executarTurno(Criatura atacante, Criatura alvo) {
        if (!atacante.estaViva()) {
            return;
        }
        
        System.out.println("\n--- TURNO DE " + atacante.getNome() + " ---");

  
        atacante.processarEfeitosStatus();
        if (!atacante.estaViva()) {
            System.out.println(atacante.getNome() + " desmaiou devido a um efeito de status.");
            return;
        }
        
        
        Habilidade ataquePadrao = new Habilidade() {
            
            public String getNome() { return "Ataque Básico"; }
           
            public void usar(Criatura atacante, Criatura alvo) {
                double danoBase = atacante.getAtk();
                double danoFinal = calculadora.calcularDanoFinal(atacante, alvo, danoBase); 
                System.out.println(atacante.getNome() + " ataca " + alvo.getNome() + " causando " + (int) danoFinal + " de dano.");
                alvo.receberDano((int) danoFinal);
            }
        };
       

        System.out.println(atacante.getNome() + " HP: " + atacante.getHp());
        System.out.println(alvo.getNome() + " HP: " + alvo.getHp());
    }

    private void declararVencedor() {
        
        if (criatura1.estaViva() && !criatura2.estaViva()) {
            System.out.println("\n" + criatura1.getNome() + " venceu a batalha!");
        } else if (!criatura1.estaViva() && criatura2.estaViva()) {
            System.out.println("\n" + criatura2.getNome() + " venceu a batalha!");
        } else {
            System.out.println("\nA batalha terminou em empate.");
        }
    }
}