/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

/**
 *
 * @author Gabriel Samartin
 */

import model.TipoElemental;
import model.Criatura;

public class CalculadoraElemental {

    public double calcularVantagem(TipoElemental tipoAtacante, TipoElemental tipoAlvo) {
        switch (tipoAtacante) {
            case FOGO:
                if (tipoAlvo == TipoElemental.TERRA) {
                    return 1.5;
                }
                if (tipoAlvo == TipoElemental.AGUA) {
                    return 0.5;
                }
                break;
            case AGUA:
                if (tipoAlvo == TipoElemental.FOGO) {
                    return 1.5;
                }
                if (tipoAlvo == TipoElemental.TERRA) {
                    return 0.5;
                }
                break;
            case TERRA:
                if (tipoAlvo == TipoElemental.AGUA) {
                    return 1.5;
                }
                if (tipoAlvo == TipoElemental.FOGO) {
                    return 0.5;
                }
                if (tipoAlvo == TipoElemental.AR) {
                    return 0.5;
                }
                break;
            case AR:
                if (tipoAlvo == TipoElemental.TERRA) {
                    return 1.5;
                }
                break;
            case LUZ:
                if (tipoAlvo == TipoElemental.TREVAS) return 1.5;
                break;
            case TREVAS:
                if (tipoAlvo == TipoElemental.LUZ) return 0.5;
                break;
        }
        
        
      
        return 1.0; 
    }
    
    public double calcularDanoFinal(Criatura atacante, Criatura alvo, double danoBase) {
        double multiplicador = calcularVantagem(atacante.getTipo(), alvo.getTipo());
        double dano = danoBase * multiplicador;
        return dano;
    }

   

}