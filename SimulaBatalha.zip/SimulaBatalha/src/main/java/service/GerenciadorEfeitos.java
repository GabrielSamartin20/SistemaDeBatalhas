/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import model.Criatura;
/**
 *
 * @author Gabriel Samartin
 */

public class GerenciadorEfeitos {

    public void processarEfeitos(Criatura criatura) {
        if (criatura.getEfeitosDeStatus() != null && !criatura.getEfeitosDeStatus().isEmpty()) {
            criatura.processarEfeitosStatus();
        }
    }
}

