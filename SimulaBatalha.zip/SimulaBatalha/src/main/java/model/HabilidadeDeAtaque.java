     /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Gabriel Samartin
 */
import model.Criatura;
import service.CalculadoraElemental;

public class HabilidadeDeAtaque implements Habilidade {
    private String nome;
    private int danoBase;
    private CalculadoraElemental calculadora = new CalculadoraElemental();

    public HabilidadeDeAtaque(String nome, int danoBase, CalculadoraElemental calculadora) {
        this.nome = nome;
        this.danoBase = danoBase;
        this.calculadora = calculadora;
    }

    


    @Override
    public String getNome() {
        return this.nome;
    }

    @Override
    public void usar(Criatura atacante, Criatura alvo) {
        double danoBruto = atacante.getAtk() + danoBase - alvo.getDef();
        if (danoBruto < 0) danoBruto = 0;
        
        double danoFinal = calculadora.calcularDanoFinal(atacante, alvo, danoBruto);
        
        System.out.println(atacante.getNome() + " usa " + this.getNome() + " em " + alvo.getNome() + "!");
        alvo.receberDano((int) danoFinal);
        System.out.println(alvo.getNome() + " recebeu " + (int) danoFinal + " de dano.");
    }
}