/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Gabriel Samartin
 */

    
public class Queimado implements EfeitoStatus {
    private String nome;
    private int duracao;
    private int danoPorTurno;

    public Queimado(int duracao, int danoPorTurno) {
        this.nome = "Queimado";
        this.duracao = duracao;
        this.danoPorTurno = danoPorTurno;
    }

    @Override
    public String getNome() {
        return this.nome;
    }

    @Override
    public int getDuracao() {
        return this.duracao;
    }

    @Override
    public void aplicarEfeito(Criatura criatura) {
        if (estaAtivo()) {
            criatura.receberDano(danoPorTurno);
            this.duracao--;
            System.out.println(criatura.getNome() + " sofre " + danoPorTurno + " de dano por queimadura.");
        }
    }

    @Override
    public boolean estaAtivo() {
        return this.duracao > 0;
    }
}
