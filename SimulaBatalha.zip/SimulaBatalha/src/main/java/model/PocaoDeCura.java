/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Gabriel Samartin
 */
import model.Criatura;
import model.Item;

public class PocaoDeCura implements Item {
    private String nome;
    private String descricao;
    private int quantidadeCura;

    public PocaoDeCura(int quantidadeCura) {
        this.nome = "Poção de Cura";
        this.descricao = "Restaura " + quantidadeCura + " de HP.";
        this.quantidadeCura = quantidadeCura;
    }

    @Override
    public String getNome() {
        return this.nome;
    }

    @Override
    public String getDescricao() {
        return this.descricao;
    }

    @Override
    public void usar(Criatura criatura) {
        int hpAtual = criatura.getHp();
        criatura.setHp(hpAtual + quantidadeCura);
        System.out.println(criatura.getNome() + " usou " + this.getNome() + " e curou " + quantidadeCura + " de HP.");
    }
}
