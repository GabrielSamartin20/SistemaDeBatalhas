/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Gabriel Samartin
 */
import model.Criatura;

public class HabilidadeDeCura implements Habilidade {
    private String nome;
    private int quantidadeCura;

    public HabilidadeDeCura(String nome, int quantidadeCura) {
        this.nome = nome;
        this.quantidadeCura = quantidadeCura;
    }

    @Override
    public String getNome() {
        return this.nome;
    }

    @Override
    public void usar(Criatura atacante, Criatura alvo) {
        alvo.setHp(alvo.getHp() + quantidadeCura);
        System.out.println(atacante.getNome() + " usa " + this.getNome() + " e cura " 
                + alvo.getNome() + " em " + quantidadeCura + " de HP.");
        
    }
}