/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Gabriel Samartin
 */
import model.Criatura;

public class HabilidadeDeDefesa implements Habilidade {
    private String nome;
    private int bonusDefesa;

    public HabilidadeDeDefesa(String nome, int bonusDefesa) {
        this.nome = nome;
        this.bonusDefesa = bonusDefesa;
    }

    @Override
    public String getNome() {
        return this.nome;
    }

    @Override
    public void usar(Criatura atacante, Criatura alvo) {
        int novaDefesa = alvo.getDef() + bonusDefesa;
        alvo.setDef(novaDefesa);
        System.out.println(alvo.getNome() + " usou " + this.getNome() + " e sua DEF aumentou em " + bonusDefesa + "!");
    }
}