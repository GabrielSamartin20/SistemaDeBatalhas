package model;

import java.util.ArrayList;
import java.util.List;

public class Criatura {
    private String nome;
    private int hp;
    private int atk;
    private int def;
    private TipoElemental tipo;
    private int velocidade;
    private List<Habilidade> habilidades;
    private List<EfeitoStatus> efeitosDeStatus;
    
    
    public Criatura(String nome, int hp, int atk, int def, TipoElemental tipo, int velocidade, List<Habilidade> habilidades) {
        this.nome = nome;
        this.hp = hp;
        this.atk = atk;
        this.def = def;
        this.tipo = tipo;
        this.velocidade = velocidade;
        this.habilidades = habilidades;
        this.efeitosDeStatus = new ArrayList<>();
    }

    
    public String getNome() { return nome; }
    public int getHp() { return hp; }
    public void setHp(int hp) { this.hp = hp; }
    public int getAtk() { return atk; }
    public int getDef() { return def; }
    public TipoElemental getTipo() { return tipo; }
    public int getVelocidade() { return velocidade; }
    public List<Habilidade> getHabilidades() { return habilidades; }
    public List<EfeitoStatus> getEfeitosDeStatus() { return efeitosDeStatus; }

    
    public void receberDano(int dano) {
        this.hp -= dano;
        if (this.hp < 0) {
            this.hp = 0;
        }
    }
    
    public void adicionarEfeitoStatus(EfeitoStatus efeito) {
        this.efeitosDeStatus.add(efeito);
    }
    
   
    public void processarEfeitosStatus() {
        List<EfeitoStatus> efeitosAtivos = new ArrayList<>();
    
        for (int i = 0; i < efeitosDeStatus.size(); i++) {
        EfeitoStatus efeito = efeitosDeStatus.get(i);
        efeito.aplicarEfeito(this);
            if (efeito.estaAtivo()) {
                efeitosAtivos.add(efeito);
            } else {
                System.out.println("O efeito de " + efeito.getNome() + " em " + this.getNome() + " terminou.");
            }
        }
    
        this.efeitosDeStatus = efeitosAtivos;
    }

    public boolean estaViva() {
        return this.hp > 0;
    }

    void setDef(int novaDefesa) {
    }
}